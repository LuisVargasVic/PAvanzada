#include <stdlib.h>
#include <stdio.h>
#include "qsort.h"

void sortById (Student *class){
  return;
}
