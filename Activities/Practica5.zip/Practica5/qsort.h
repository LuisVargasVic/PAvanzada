typedef struct s{
  int id;
  char *name;
} Student;

typedef int entero;
